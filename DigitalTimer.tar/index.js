// Write your code here
import {Component} from 'react'

import './index.css'

class DigitalTimer extends Component {
  state = {
    isTimerRunning: false,
    secs: 0,
    mins: 25,
  }

  onDec = () => {
    const {isTimerRunning} = this.state

    if (!isTimerRunning) {
      this.setState(prevState => ({
        mins: prevState.mins - 1,
      }))
    }
  }

  onIn = () => {
    const {isTimerRunning} = this.state

    if (!isTimerRunning) {
      this.setState(prevState => ({
        mins: prevState.mins + 1,
      }))
    }
  }

  onReset = () => {
    this.setState(prevState => ({
      isTimerRunning: !prevState.isTimerRunning,
      mins: 25,
      secs: 0,
    }))
    clearInterval(this.timer)
  }

  onStartOrPauseTimer = () => {
    const {isTimerRunning} = this.state

    if (!isTimerRunning) {
      this.timer = setInterval(this.tick, 1000)
    } else {
      clearInterval(this.timer)
    }

    this.setState(prevState => ({isTimerRunning: !prevState.isTimerRunning}))
    // 9. Toggling the state isTimerRunning based on the previous state
  }

  tick = () => {
    const {secs, mins} = this.state
    if (secs === 0) {
      this.setState(prevState => ({
        secs: prevState.secs + 60,
        mins: prevState.mins - 1,
      }))
    }

    if (mins === 0 && secs === 0) {
      this.setState(prevState => ({
        isTimerRunning: !prevState.isTimerRunning,
        mins: 25,
        secs: 1,
      }))
      clearInterval(this.timer)
    }
    this.setState(prevState => ({secs: prevState.secs - 1}))
  }

  render() {
    const {isTimerRunning, secs, mins} = this.state

    const stringifiedMinutes = mins > 9 ? mins : `0${mins}`
    const stringifiedSeconds = secs > 9 ? secs : `0${secs}`
    const startOrPauseImageUrl = isTimerRunning
      ? 'https://assets.ccbp.in/frontend/react-js/pause-icon-img.png'
      : 'https://assets.ccbp.in/frontend/react-js/play-icon-img.png'
    const startOrPauseAltText = isTimerRunning ? 'pause icon' : 'play icon'
    const startOrPauseText = isTimerRunning ? 'Running' : 'Paused'

    return (
      <div className="bg-container">
        <h1 className="hg">Digital Timer</h1>
        <div className="items">
          <div className="item1">
            <h1>
              {stringifiedMinutes}:{stringifiedSeconds}
            </h1>
            <p>{startOrPauseText}</p>
          </div>
          <div className="cont">
            <button
              id="spBtn"
              className="timer-controller-btn"
              onClick={this.onStartOrPauseTimer}
              type="button"
            >
              <img
                alt={startOrPauseAltText}
                className="timer-controller-icon"
                src={startOrPauseImageUrl}
              />
            </button>
            <label htmlFor="spBtn" className="timer-controller-label">
              {isTimerRunning ? 'Pause' : 'Start'}
            </label>
            <button
              id="resetBtn"
              className="timer-controller-btn"
              onClick={this.onReset}
              type="button"
            >
              <img
                alt="reset icon"
                className="timer-controller-icon"
                src="https://assets.ccbp.in/frontend/react-js/reset-icon-img.png"
              />
            </button>
            <label htmlFor="resetBtn" className="timer-controller-label">
              Reset
            </label>
            <div>
              <p>Set Timer limit</p>
              <div className="item22">
                <button onClick={this.onDec} type="button">
                  -
                </button>
                <p>{mins}</p>
                <button onClick={this.onIn} type="button">
                  +
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
export default DigitalTimer
